<?php
include('includes/config.php');

?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Readers Campus Post| Contact us</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">

  </head>

  <body>

    <!-- Navigation -->
    <?php include('includes/header.php');?>

    <!-- Page Content -->
    <div class="container">

<?php 
$pagetype='contactus';
$query=mysqli_query($con,"select PageTitle,Description from tblpages where PageName='$pagetype'");
while($row=mysqli_fetch_array($query))
{

?>
      <h1 class="mt-4 mb-3"><?php echo htmlentities($row['PageTitle'])?>
  
      </h1>

      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Home</a>
        </li>
        <li class="breadcrumb-item active">Contact</li>
      </ol>

      <!-- Intro Content -->
      <div class="row">

        <div class="col-lg-12">

          <p><?php echo $row['Description'];?></p>
        </div>
      </div>
      <!-- /.row -->
<?php } ?>

<br>

<section class="pt-0 pb-20">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-lg-8">
          <div class="p-30 mb-30 card-view">
            <h4 class="p-title"><b>Please fill the form to advertise with us</b></h4>
            <form action="process.php" method="post">
              <div class="row">
                <div class="col-sm-6">
                  <input class="mb-30" name="name" required   type="text" placeholder="Your name"><br>
                </div><!-- col-sm-6 -->
                <div class="col-sm-6">
                  <input class="mb-30" name="email" required   type="text" placeholder="Your email"><br>
                </div><!-- col-sm-6 -->
                <div class="col-sm-6">
                  <a style="width: 300px;" href="tel:0754655583"><button type="SUBMIT" >MoMo Pay</button></a>
                </div>
                <div class="col-sm-12">
                  <textarea class="mb-30" name="message" required   placeholder="How you want your advert to be."></textarea>



                </div><!-- col-sm-12 -->
                
              </div><!-- row -->
              
              <button class="btn-fill-primary plr-20" ><b>SUBMIT NOW</b></button>
            </form>
          </div><!-- card-view -->
        </div><!-- col-sm-12 -->
        <div class="col-md-12 col-lg-4">
          
          <div class="p-30 mb-30 card-view">
            <h4 class="p-title"><b>OUR OFFICE</b></h4>
            <ul class="list-contact list-li-mb-20">
              <li><i class="ion-ios-home"></i>Mengo, Kampala, Uganda</li>
              <li><a href="#"><i class="ion-ios-telephone"></i>(+256) 754655583</a></li>
              <li><a href="#"><i class="ion-email"></i>sharon@gmail.com</a></li>
              <li class="mb-0"><a href="#"><i class="ion-ios-world"></i>www.readerscampuspost.com</a></li>
            </ul>
          </div><!-- card-view -->
        </div><!-- col-sm-12 -->
        
      </div><!-- row -->
    </div><!-- container -->
  </section>


    
    </div>
    <br>
    <!-- /.container -->

    <!-- Footer -->
 <?php include('includes/footer.php');?>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
