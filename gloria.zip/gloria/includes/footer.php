    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Nawhera Gloria</p>
          <p class="m-0 text-center text-white"> 18/2/314/E/</p>

      </div>
     
    </footer>